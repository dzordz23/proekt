package com.example.film_production_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilmProductionManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
