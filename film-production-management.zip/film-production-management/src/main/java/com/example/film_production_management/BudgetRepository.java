package com.example.filmproductionmanagement.repository;

import com.example.filmproductionmanagement.model.Budget;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BudgetRepository extends JpaRepository<Budget, Long> {
}