package com.example.filmproductionmanagement.repository;

import com.example.filmproductionmanagement.model.DistributionChannel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DistributionChannelRepository extends JpaRepository<DistributionChannel, Long> {
}