package com.example.filmproductionmanagement.model;

import javax.persistence.*;
import java.util.Set;

@Entity
public class Film {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String title;
    private String genre;
    private String director;

    @OneToMany(mappedBy = "film")
    private Set<CrewMember> crewMembers;

    @OneToMany(mappedBy = "film")
    private Set<Schedule> schedules;

    @OneToMany(mappedBy = "film")
    private Set<Budget> budgets;

    @OneToMany(mappedBy = "film")
    private Set<DistributionChannel> distributionChannels;

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public Set<CrewMember> getCrewMembers() {
        return crewMembers;
    }

    public void setCrewMembers(Set<CrewMember> crewMembers) {
        this.crewMembers = crewMembers;
    }

    public Set<Schedule> getSchedules() {
        return schedules;
    }

    public void setSchedules(Set<Schedule> schedules) {
        this.schedules = schedules;
    }

    public Set<Budget> getBudgets() {
        return budgets;
    }

    public void setBudgets(Set<Budget> budgets) {
        this.budgets = budgets;
    }

    public Set<DistributionChannel> getDistributionChannels() {
        return distributionChannels;
    }

    public void setDistributionChannels(Set<DistributionChannel> distributionChannels) {
        this.distributionChannels = distributionChannels;
    }
}
