package com.example.filmproductionmanagement.repository;

import com.example.filmproductionmanagement.model.CrewMember;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CrewMemberRepository extends JpaRepository<CrewMember, Long> {
}
